import React, { useState } from 'react';
import { ServiceCard } from './components/ServiceCard';
import { OrderForm } from './components/OrderForm';
import { LanguageSwitch } from './components/LanguageSwitch';
import { Features } from './components/Features';
import { Testimonials } from './components/Testimonials';
import { FAQ } from './components/FAQ';
import { useLanguage } from './hooks/useLanguage';
import { translations } from './i18n/translations';

function App() {
  const [showOrderForm, setShowOrderForm] = useState(false);
  const [selectedService, setSelectedService] = useState<'stars' | 'premium' | null>(null);
  const [quantity, setQuantity] = useState(0);
  const { language } = useLanguage();
  const t = translations[language];

  const handleOrder = (service: 'stars' | 'premium', serviceQuantity: number) => {
    setSelectedService(service);
    setQuantity(serviceQuantity);
    setShowOrderForm(true);
  };

  const handleSubmitOrder = (telegramId: string, phoneNumber: string) => {
    // Here you would typically submit the order to your backend
    console.log('Order submitted:', { 
      service: selectedService, 
      quantity,
      telegramId, 
      phoneNumber 
    });
    setShowOrderForm(false);
    setSelectedService(null);
    setQuantity(0);
  };

  return (
    <div className={`min-h-screen bg-[#f4f4f5] ${language === 'fa' ? 'rtl' : 'ltr'}`}>
      <LanguageSwitch />
      
      <div className="container mx-auto px-4 py-12">
        <h1 className="text-4xl font-bold text-center mb-4 text-[#232323]">{t.title}</h1>
        <p className="text-center text-gray-600 mb-12 text-lg">
          {t.subtitle}
        </p>

        <Features />
        
        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto mb-16">
          <ServiceCard
            type="stars"
            price={99}
            onOrder={(quantity) => handleOrder('stars', quantity)}
          />
          <ServiceCard
            type="premium"
            price={199}
            onOrder={(quantity) => handleOrder('premium', quantity)}
          />
        </div>

        <Testimonials />
        <FAQ />
      </div>

      {showOrderForm && (
        <OrderForm
          onSubmit={handleSubmitOrder}
          onCancel={() => setShowOrderForm(false)}
        />
      )}
    </div>
  );
}

export default App;