import { create } from 'zustand';

interface LanguageState {
  language: 'en' | 'fa';
  setLanguage: (language: 'en' | 'fa') => void;
}

export const useLanguage = create<LanguageState>((set) => ({
  language: 'en',
  setLanguage: (language) => set({ language }),
}));