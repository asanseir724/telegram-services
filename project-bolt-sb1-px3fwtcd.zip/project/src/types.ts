export interface ServicePrice {
  stars: number;
  premium: number;
  commission: number;
}

export interface Order {
  id: string;
  service: 'stars' | 'premium';
  telegramId: string;
  phoneNumber: string;
  status: 'pending' | 'completed' | 'cancelled';
  createdAt: string;
}

export interface Language {
  code: 'en' | 'fa';
  name: string;
  direction: 'ltr' | 'rtl';
}