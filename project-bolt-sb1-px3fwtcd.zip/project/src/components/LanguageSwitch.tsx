import { Globe } from 'lucide-react';
import { useLanguage } from '../hooks/useLanguage';

export function LanguageSwitch() {
  const { language, setLanguage } = useLanguage();

  return (
    <button
      onClick={() => setLanguage(language === 'en' ? 'fa' : 'en')}
      className="fixed top-4 right-4 p-2 rounded-xl bg-white/80 backdrop-blur-sm shadow-lg hover:bg-white transition-all"
    >
      <Globe className="w-6 h-6 text-[#3390ec]" />
    </button>
  );
}