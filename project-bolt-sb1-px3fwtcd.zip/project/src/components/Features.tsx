import { Zap, HeadphonesIcon, ShieldCheck, Award } from 'lucide-react';
import { useLanguage } from '../hooks/useLanguage';
import { translations } from '../i18n/translations';

export function Features() {
  const { language } = useLanguage();
  const t = translations[language];

  const features = [
    { icon: Zap, text: t.features.instant },
    { icon: HeadphonesIcon, text: t.features.support },
    { icon: ShieldCheck, text: t.features.secure },
    { icon: Award, text: t.features.guarantee },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto mb-16">
      {features.map((feature, index) => (
        <div
          key={index}
          className="bg-white rounded-xl p-4 text-center flex flex-col items-center shadow-md hover:shadow-lg transition-shadow"
        >
          <feature.icon className="w-8 h-8 text-[#3390ec] mb-2" />
          <span className="text-sm font-medium text-gray-700">{feature.text}</span>
        </div>
      ))}
    </div>
  );
}