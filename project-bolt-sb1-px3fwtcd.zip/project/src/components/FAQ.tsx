import { ChevronDown, ChevronUp } from 'lucide-react';
import { useLanguage } from '../hooks/useLanguage';
import { translations } from '../i18n/translations';
import { useState } from 'react';

export function FAQ() {
  const { language } = useLanguage();
  const t = translations[language];
  const [openQuestion, setOpenQuestion] = useState<string | null>(null);

  const questions = Object.entries(t.faq.questions);

  return (
    <div className="max-w-2xl mx-auto mb-16">
      <h2 className="text-2xl font-bold text-center mb-8 text-[#232323]">
        {t.faq.title}
      </h2>
      <div className="space-y-4">
        {questions.map(([key, { q, a }]) => (
          <div
            key={key}
            className="bg-white rounded-xl overflow-hidden shadow-md"
          >
            <button
              className="w-full px-6 py-4 text-left flex items-center justify-between hover:bg-gray-50 transition-colors"
              onClick={() => setOpenQuestion(openQuestion === key ? null : key)}
            >
              <span className="font-medium text-[#232323]">{q}</span>
              {openQuestion === key ? (
                <ChevronUp className="w-5 h-5 text-gray-500" />
              ) : (
                <ChevronDown className="w-5 h-5 text-gray-500" />
              )}
            </button>
            {openQuestion === key && (
              <div className="px-6 py-4 bg-gray-50 text-gray-600">
                {a}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}