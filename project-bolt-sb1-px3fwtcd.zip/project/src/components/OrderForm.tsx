import { useState } from 'react';
import { useLanguage } from '../hooks/useLanguage';
import { translations } from '../i18n/translations';
import { X } from 'lucide-react';

interface OrderFormProps {
  onSubmit: (telegramId: string, phoneNumber: string) => void;
  onCancel: () => void;
}

export function OrderForm({ onSubmit, onCancel }: OrderFormProps) {
  const [telegramId, setTelegramId] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const { language } = useLanguage();
  const t = translations[language];

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl w-full max-w-md overflow-hidden">
        <div className="bg-[#3390ec] p-4 flex items-center justify-between">
          <h2 className="text-white text-lg font-medium">{t.submit}</h2>
          <button 
            onClick={onCancel}
            className="text-white/80 hover:text-white transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>
        <div className="p-6 space-y-4">
          <div>
            <input
              type="text"
              placeholder={t.telegramId}
              value={telegramId}
              onChange={(e) => setTelegramId(e.target.value)}
              className="w-full p-3 border border-gray-200 rounded-xl focus:border-[#3390ec] focus:ring-1 focus:ring-[#3390ec] outline-none transition-all"
            />
          </div>
          <div>
            <input
              type="tel"
              placeholder={t.phoneNumber}
              value={phoneNumber}
              onChange={(e) => setPhoneNumber(e.target.value)}
              className="w-full p-3 border border-gray-200 rounded-xl focus:border-[#3390ec] focus:ring-1 focus:ring-[#3390ec] outline-none transition-all"
            />
          </div>
          <div className="flex gap-3 pt-2">
            <button
              onClick={() => onSubmit(telegramId, phoneNumber)}
              className="flex-1 py-3 bg-[#3390ec] text-white rounded-xl hover:bg-[#147fdb] transition-colors font-medium"
            >
              {t.submit}
            </button>
            <button
              onClick={onCancel}
              className="flex-1 py-3 bg-gray-100 text-gray-700 rounded-xl hover:bg-gray-200 transition-colors font-medium"
            >
              {t.cancel}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}