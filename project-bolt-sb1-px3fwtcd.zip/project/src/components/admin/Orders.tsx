import {
  createColumnHelper,
  flexRender,
  getCoreRowModel,
  useReactTable,
} from '@tanstack/react-table';
import { useLanguage } from '../../hooks/useLanguage';
import { translations } from '../../i18n/translations';
import type { Order } from '../../types';

const columnHelper = createColumnHelper<Order>();

export function Orders() {
  const { language } = useLanguage();
  const t = translations[language];

  // Example data - replace with real data from your backend
  const data: Order[] = [
    {
      id: '1',
      service: 'stars',
      telegramId: '@user1',
      phoneNumber: '+1234567890',
      status: 'pending',
      createdAt: new Date().toISOString(),
    },
    {
      id: '2',
      service: 'premium',
      telegramId: '@user2',
      phoneNumber: '+9876543210',
      status: 'completed',
      createdAt: new Date().toISOString(),
    },
  ];

  const columns = [
    columnHelper.accessor('id', {
      header: 'ID',
      cell: (info) => info.getValue(),
    }),
    columnHelper.accessor('service', {
      header: t.service,
      cell: (info) => t[info.getValue()],
    }),
    columnHelper.accessor('telegramId', {
      header: t.telegramId,
      cell: (info) => info.getValue(),
    }),
    columnHelper.accessor('phoneNumber', {
      header: t.phoneNumber,
      cell: (info) => info.getValue(),
    }),
    columnHelper.accessor('status', {
      header: t.status,
      cell: (info) => {
        const status = info.getValue();
        const statusClasses = {
          pending: 'bg-yellow-100 text-yellow-800',
          completed: 'bg-green-100 text-green-800',
          cancelled: 'bg-red-100 text-red-800',
        };

        return (
          <span
            className={`px-2 py-1 rounded-full text-sm ${
              statusClasses[status]
            }`}
          >
            {t[status]}
          </span>
        );
      },
    }),
  ];

  const table = useReactTable({
    data,
    columns,
    getCoreRowModel: getCoreRowModel(),
  });

  return (
    <div className="bg-white rounded-xl shadow-md overflow-hidden">
      <div className="p-6 border-b">
        <h2 className="text-xl font-bold text-[#232323]">{t.orders}</h2>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-50">
            {table.getHeaderGroups().map((headerGroup) => (
              <tr key={headerGroup.id}>
                {headerGroup.headers.map((header) => (
                  <th
                    key={header.id}
                    className="px-6 py-3 text-left text-sm font-medium text-gray-500"
                  >
                    {flexRender(
                      header.column.columnDef.header,
                      header.getContext()
                    )}
                  </th>
                ))}
              </tr>
            ))}
          </thead>
          <tbody>
            {table.getRowModel().rows.map((row) => (
              <tr key={row.id} className="border-t border-gray-200">
                {row.getVisibleCells().map((cell) => (
                  <td
                    key={cell.id}
                    className="px-6 py-4 text-sm text-gray-900"
                  >
                    {flexRender(cell.column.columnDef.cell, cell.getContext())}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}