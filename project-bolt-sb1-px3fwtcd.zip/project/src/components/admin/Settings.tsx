import { useState } from 'react';
import { useLanguage } from '../../hooks/useLanguage';
import { translations } from '../../i18n/translations';

export function Settings() {
  const { language } = useLanguage();
  const t = translations[language];
  
  const [prices, setPrices] = useState({
    stars: 99,
    premium: 199,
    commission: 10,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Here you would typically save the settings to your backend
    console.log('Settings saved:', prices);
  };

  return (
    <div className="bg-white rounded-xl shadow-md overflow-hidden">
      <div className="p-6 border-b">
        <h2 className="text-xl font-bold text-[#232323]">{t.settings}</h2>
      </div>
      <form onSubmit={handleSubmit} className="p-6 space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            {t.stars} {t.price}
          </label>
          <div className="relative rounded-lg">
            <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-500">
              $
            </span>
            <input
              type="number"
              value={prices.stars}
              onChange={(e) =>
                setPrices({ ...prices, stars: Number(e.target.value) })
              }
              className="block w-full pl-8 pr-4 py-2 border border-gray-200 rounded-lg focus:ring-1 focus:ring-[#3390ec] focus:border-[#3390ec] outline-none"
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            {t.premium} {t.price}
          </label>
          <div className="relative rounded-lg">
            <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-500">
              $
            </span>
            <input
              type="number"
              value={prices.premium}
              onChange={(e) =>
                setPrices({ ...prices, premium: Number(e.target.value) })
              }
              className="block w-full pl-8 pr-4 py-2 border border-gray-200 rounded-lg focus:ring-1 focus:ring-[#3390ec] focus:border-[#3390ec] outline-none"
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            {t.commission} (%)
          </label>
          <input
            type="number"
            value={prices.commission}
            onChange={(e) =>
              setPrices({ ...prices, commission: Number(e.target.value) })
            }
            className="block w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-1 focus:ring-[#3390ec] focus:border-[#3390ec] outline-none"
          />
        </div>

        <button
          type="submit"
          className="w-full py-3 bg-[#3390ec] text-white rounded-xl hover:bg-[#147fdb] transition-colors font-medium"
        >
          {t.submit}
        </button>
      </form>
    </div>
  );
}