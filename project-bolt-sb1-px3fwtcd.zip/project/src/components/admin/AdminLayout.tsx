import { NavLink, Outlet } from 'react-router-dom';
import { LayoutDashboard, Settings as SettingsIcon } from 'lucide-react';
import { useLanguage } from '../../hooks/useLanguage';
import { translations } from '../../i18n/translations';

export function AdminLayout() {
  const { language } = useLanguage();
  const t = translations[language];

  return (
    <div className="min-h-screen bg-[#f4f4f5] flex">
      {/* Sidebar */}
      <div className="w-64 bg-white shadow-md">
        <div className="p-4 border-b">
          <h1 className="text-xl font-bold text-[#232323]">{t.adminPanel}</h1>
        </div>
        <nav className="p-4 space-y-2">
          <NavLink
            to="/admin/orders"
            className={({ isActive }) =>
              `flex items-center space-x-2 p-2 rounded-lg transition-colors ${
                isActive
                  ? 'bg-[#3390ec] text-white'
                  : 'text-gray-600 hover:bg-gray-100'
              }`
            }
          >
            <LayoutDashboard className="w-5 h-5" />
            <span>{t.orders}</span>
          </NavLink>
          <NavLink
            to="/admin/settings"
            className={({ isActive }) =>
              `flex items-center space-x-2 p-2 rounded-lg transition-colors ${
                isActive
                  ? 'bg-[#3390ec] text-white'
                  : 'text-gray-600 hover:bg-gray-100'
              }`
            }
          >
            <SettingsIcon className="w-5 h-5" />
            <span>{t.settings}</span>
          </NavLink>
        </nav>
      </div>

      {/* Main content */}
      <div className="flex-1 p-8">
        <Outlet />
      </div>
    </div>
  );
}