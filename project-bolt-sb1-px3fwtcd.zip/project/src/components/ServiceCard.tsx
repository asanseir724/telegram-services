import { Star, Crown, Minus, Plus } from 'lucide-react';
import { useLanguage } from '../hooks/useLanguage';
import { translations } from '../i18n/translations';
import { useState } from 'react';

interface ServiceCardProps {
  type: 'stars' | 'premium';
  price: number;
  onOrder: (quantity: number) => void;
}

export function ServiceCard({ type, price, onOrder }: ServiceCardProps) {
  const { language } = useLanguage();
  const t = translations[language];
  const [quantity, setQuantity] = useState(type === 'stars' ? 10 : 1);

  const handleIncrement = () => {
    if (type === 'stars' && quantity < 1000) {
      setQuantity(q => q + 10);
    } else if (type === 'premium' && quantity < 12) {
      setQuantity(q => q + 1);
    }
  };

  const handleDecrement = () => {
    if (type === 'stars' && quantity > 10) {
      setQuantity(q => q - 10);
    } else if (type === 'premium' && quantity > 1) {
      setQuantity(q => q - 1);
    }
  };

  const totalPrice = price * (type === 'stars' ? quantity / 10 : quantity);

  return (
    <div className="bg-white rounded-2xl shadow-lg hover:shadow-xl transition-shadow overflow-hidden">
      <div className="bg-[#3390ec] p-8 flex items-center justify-center">
        {type === 'stars' ? (
          <Star className="w-16 h-16 text-white" strokeWidth={1.5} />
        ) : (
          <Crown className="w-16 h-16 text-white" strokeWidth={1.5} />
        )}
      </div>
      <div className="p-6">
        <h3 className="text-xl font-medium text-center mb-2 text-[#232323]">
          {t[type]}
        </h3>
        
        <div className="flex items-center justify-center gap-4 mb-6">
          <button 
            onClick={handleDecrement}
            className="w-8 h-8 flex items-center justify-center rounded-full bg-gray-100 hover:bg-gray-200 transition-colors"
          >
            <Minus className="w-4 h-4 text-gray-600" />
          </button>
          
          <div className="text-center">
            <div className="text-lg font-medium text-[#232323]">
              {type === 'stars' ? (
                <>{quantity} {t.stars}</>
              ) : (
                <>{quantity} {quantity === 1 ? t.month : t.months}</>
              )}
            </div>
            <div className="text-3xl font-bold text-[#3390ec]">
              ${totalPrice}
            </div>
          </div>

          <button 
            onClick={handleIncrement}
            className="w-8 h-8 flex items-center justify-center rounded-full bg-gray-100 hover:bg-gray-200 transition-colors"
          >
            <Plus className="w-4 h-4 text-gray-600" />
          </button>
        </div>

        <button
          onClick={() => onOrder(quantity)}
          className="w-full py-3 px-4 bg-[#3390ec] text-white rounded-xl hover:bg-[#147fdb] transition-colors font-medium"
        >
          {t.submit}
        </button>
      </div>
    </div>
  );
}