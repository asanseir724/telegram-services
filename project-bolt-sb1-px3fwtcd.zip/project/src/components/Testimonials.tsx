import { useLanguage } from '../hooks/useLanguage';
import { translations } from '../i18n/translations';
import { MessageSquare } from 'lucide-react';

export function Testimonials() {
  const { language } = useLanguage();
  const t = translations[language];

  return (
    <div className="max-w-4xl mx-auto mb-16">
      <h2 className="text-2xl font-bold text-center mb-8 text-[#232323]">
        {t.testimonials.title}
      </h2>
      <div className="grid md:grid-cols-3 gap-6">
        {t.testimonials.items.map((testimonial, index) => (
          <div
            key={index}
            className="bg-white rounded-xl p-6 shadow-md hover:shadow-lg transition-shadow"
          >
            <div className="flex items-start mb-4">
              <div className="w-10 h-10 rounded-full bg-[#3390ec] flex items-center justify-center">
                <MessageSquare className="w-5 h-5 text-white" />
              </div>
              <div className="ml-3">
                <h3 className="font-medium text-[#232323]">{testimonial.name}</h3>
              </div>
            </div>
            <p className="text-gray-600">{testimonial.text}</p>
          </div>
        ))}
      </div>
    </div>
  );
}