export const translations = {
  en: {
    title: 'Telegram Services Shop',
    subtitle: 'Purchase Telegram Stars and Premium services easily',
    stars: 'Stars',
    premium: 'Telegram Premium',
    telegramId: 'Telegram ID',
    phoneNumber: 'Phone Number',
    submit: 'Submit Order',
    cancel: 'Cancel',
    price: 'Price',
    commission: 'Commission',
    status: 'Status',
    adminPanel: 'Admin Panel',
    orders: 'Orders',
    settings: 'Settings',
    pending: 'Pending',
    completed: 'Completed',
    cancelled: 'Cancelled',
    month: 'Month',
    months: 'Months',
    features: {
      instant: 'Instant Delivery',
      support: '24/7 Support',
      secure: 'Secure Payment',
      guarantee: '100% Guarantee'
    },
    faq: {
      title: 'Frequently Asked Questions',
      questions: {
        what: {
          q: 'What are Telegram Stars?',
          a: 'Telegram Stars are special badges that appear next to your messages, showing your support for the platform and giving you exclusive features.'
        },
        how: {
          q: 'How does the delivery process work?',
          a: 'After your order is confirmed and payment is processed, we automatically deliver your Stars or Premium subscription within minutes.'
        },
        safe: {
          q: 'Is it safe to purchase here?',
          a: 'Yes, we use secure payment methods and never store your sensitive information. Your Telegram account security is our top priority.'
        },
        refund: {
          q: 'What is your refund policy?',
          a: 'If we cannot deliver your order within 24 hours, you will receive a full refund automatically.'
        }
      }
    },
    testimonials: {
      title: 'What Our Customers Say',
      items: [
        {
          name: 'Alex',
          text: 'Fast delivery and excellent support. Got my Stars within minutes!'
        },
        {
          name: 'Sarah',
          text: 'The Premium subscription was activated instantly. Very reliable service.'
        },
        {
          name: 'Michael',
          text: 'Best prices I\'ve found for Telegram Stars. Will definitely use again.'
        }
      ]
    }
  },
  fa: {
    title: 'فروشگاه خدمات تلگرام',
    subtitle: 'خرید آسان ستاره و پریمیوم تلگرام',
    stars: 'ستاره',
    premium: 'پریمیوم تلگرام',
    telegramId: 'آیدی تلگرام',
    phoneNumber: 'شماره تلفن',
    submit: 'ثبت سفارش',
    cancel: 'انصراف',
    price: 'قیمت',
    commission: 'کمیسیون',
    status: 'وضعیت',
    adminPanel: 'پنل مدیریت',
    orders: 'سفارشات',
    settings: 'تنظیمات',
    pending: 'در انتظار',
    completed: 'تکمیل شده',
    cancelled: 'لغو شده',
    month: 'ماه',
    months: 'ماه',
    features: {
      instant: 'تحویل فوری',
      support: 'پشتیبانی ۲۴/۷',
      secure: 'پرداخت امن',
      guarantee: 'تضمین ۱۰۰٪'
    },
    faq: {
      title: 'سوالات متداول',
      questions: {
        what: {
          q: 'ستاره های تلگرام چیست؟',
          a: 'ستاره های تلگرام نشان های ویژه ای هستند که در کنار پیام های شما ظاهر می شوند و نشان دهنده حمایت شما از پلتفرم هستند و به شما امکانات انحصاری می دهند.'
        },
        how: {
          q: 'فرآیند تحویل چگونه است؟',
          a: 'پس از تایید سفارش و پردازش پرداخت، ما به طور خودکار ستاره ها یا اشتراک پریمیوم شما را در عرض چند دقیقه تحویل می دهیم.'
        },
        safe: {
          q: 'آیا خرید از اینجا امن است؟',
          a: 'بله، ما از روش های پرداخت امن استفاده می کنیم و هرگز اطلاعات حساس شما را ذخیره نمی کنیم. امنیت حساب تلگرام شما اولویت اصلی ماست.'
        },
        refund: {
          q: 'سیاست بازپرداخت شما چیست؟',
          a: 'اگر نتوانیم سفارش شما را در عرض ۲۴ ساعت تحویل دهیم، به طور خودکار مبلغ کامل را بازپرداخت خواهید کرد.'
        }
      }
    },
    testimonials: {
      title: 'نظرات مشتریان ما',
      items: [
        {
          name: 'علی',
          text: 'تحویل سریع و پشتیبانی عالی. ستاره ها رو در عرض چند دقیقه دریافت کردم!'
        },
        {
          name: 'سارا',
          text: 'اشتراک پریمیوم بلافاصله فعال شد. سرویس بسیار قابل اعتماد.'
        },
        {
          name: 'محمد',
          text: 'بهترین قیمت‌هایی که برای ستاره‌های تلگرام پیدا کردم. حتما دوباره استفاده خواهم کرد.'
        }
      ]
    }
  }
};